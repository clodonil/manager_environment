import os

ENV        = 'development'
DB_URL     = 'db_url'
DB_USER    = 'db_user'
DB_PASSWD  = 'db_passwd'